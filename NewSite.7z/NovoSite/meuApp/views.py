from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from .forms import UsuarioForm
from django.http import HttpResponse
from django.shortcuts import render
from .models import Usuario

def index(request): return HttpResponse("Hello, world. You're at the polls index.")

# Create your views here.

def cadastrar_usuario(request):
  if request.method == 'POST': # If the form has been submitted...
      form = UsuarioForm(request.POST) # Um form com os dados de POST
      if form.is_valid(): # All validation rules pass
         # Processa os dados no form.cleaned_data
         # ...
        nome = form.cleaned_data['nome']
        email = form.cleaned_data['email']
        sexo = form.cleaned_data['sexo']
          
        arquivo = open('teste.txt', 'w')
        arquivo.writelines(nome+ "\n")
        arquivo.writelines(email+ "\n")
        arquivo.writelines(sexo+ "\n")
          

        arquivo.close()

        return HttpResponseRedirect('/cadastrar_usuario') # Redireciona depois do POST
  else:
      form = UsuarioForm() # Um formulário vazio



  return render(request, "form.html", {'form':form})

    