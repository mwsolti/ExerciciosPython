from django.shortcuts import render
from .forms import UsuarioForm
from django.http import HttpResponse
from django.shortcuts import render
from .models import Usuario

def index(request): return HttpResponse("Hello, world. You're at the polls index.")

# Create your views here.

def cadastrar_usuario(request):
   
    form = UsuarioForm(request.POST)

    if form.is_valid():
        user = Usuario()
        user.nome = form.cleaned_data['nome']
        user.email = form.cleaned_data['email']
        user.sexo = form.cleaned_data['sexo']
        user.save()

    form = UsuarioForm()
    return render(request, "form.html", {'form':form})



def teste(request):
  form = UsuarioForm(request.POST)
  print(form.cleaned_data('nome'))
  if form.is_valid():
    
    user = Usuario()

    user.email = form.cleaned_data['email']
    user.sexo = form.cleaned_data['sexo']
    user.save()

  form = UsuarioForm()
  return render(request, "form.html", {'form':form})
    